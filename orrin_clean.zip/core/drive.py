# drive.py
from datetime import datetime, timezone
from utils.log import log_private, log_error
from utils.json_utils import extract_json
from memory.working_memory import update_working_memory
from cognition.reflection.meta_reflect import meta_reflect
from emotion.amygdala import process_emotional_signals
from utils.generate_response import generate_response

def persistent_drive_loop(context, self_model, memory):
    try:
        # === 1. Emotional threat check
        context, amygdala_response = process_emotional_signals(context)
        if amygdala_response.get("threat_detected"):
            shortcut = amygdala_response.get("shortcut_function", "self_soothing")
            tags = amygdala_response.get("threat_tags", [])
            spike = amygdala_response.get("spike_intensity", 0.0)
            update_working_memory({
                "content": f"⚠️ Amygdala override: Detected {tags[0] if tags else 'unknown'} threat. "
                           f"Spike: {spike}. Redirecting to: {shortcut}.",
                "event_type": "amygdala_override",
                "intensity": spike,
                "priority": 3,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            return shortcut  # always return a function name

        # === Optional: Bypass if emotionally secure
        stability = context.get("emotional_state", {}).get("emotional_stability", 1.0)
        if stability > 0.8:
            update_working_memory({
                "content": "✅ Emotionally secure — skipping deep internal reflection.",
                "event_type": "security_check",
                "priority": 1,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            return "choose_next_cognition"  # keep return type consistent

        # === 2. Snapshot directive + reflection
        directive = self_model.get("core_directive", {}).get("statement", "")
        identity = self_model.get("identity", "")
        recent_mem = "\n".join(
            f"- {m.get('content', '')}" for m in memory[-25:] if isinstance(m, dict) and m.get("content")
        )

        summary = meta_reflect({
            "goal": "Evaluate internal state and directive alignment",
            "core_directive": directive,
            "identity": identity,
            "recent_memory": recent_mem
        })
        if not summary or not isinstance(summary, str):
            raise ValueError("meta_reflect() returned invalid summary")

        update_working_memory({
            "content": f"🧭 Drive loop reflection:\n{summary}",
            "event_type": "reflection",
            "importance": 2,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        log_private(f"\n[{datetime.now(timezone.utc)}] Persistent drive summary:\n{summary}")

        # === 3. LLM-Based Decision: What cognition is needed most?
        available_functions = context.get("available_functions", {}) or {}
        if not available_functions:
            update_working_memory({
                "content": "ℹ️ No available functions provided; defaulting to introspective_planning.",
                "event_type": "drive_choice",
                "importance": 1,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            return "introspective_planning"

        past_choices = context.get("cognition_log", [])[-5:]
        recent_choices = ", ".join([c.get("choice", "") for c in past_choices if isinstance(c, dict)])

        options_str = "\n".join(f"- {fn}" for fn in available_functions.keys())

        prompt = (
            "You are Orrin, an autonomous AI.\n"
            f"Directive: {directive}\n"
            f"Identity: {identity}\n"
            f"Recent cognition: {recent_choices or 'none'}\n"
            f"Summary of internal reflection:\n{summary}\n\n"
            f"Available functions:\n{options_str}\n"
            "Based on your state and goals, which cognitive function should come next?\n"
            "Avoid repeating the same action too often.\n"
            "Respond as JSON: {\"choice\": \"function_name\", \"reason\": \"\"}"
        )

        response = generate_response(prompt)
        decision = extract_json(response) if response else {}

        if not isinstance(decision, dict) or "choice" not in decision:
            update_working_memory({
                "content": "⚠️ Invalid decision in drive loop; defaulting to introspective_planning.",
                "event_type": "drive_loop",
                "priority": 2,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            return "introspective_planning"

        update_working_memory({
            "content": f"🔥 Persistent drive chose: {decision['choice']} — {decision.get('reason', 'no reason')}",
            "event_type": "drive_choice",
            "importance": 2,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        return decision["choice"]

    except Exception as e:
        log_error(f"persistent_drive_loop ERROR: {e}")
        update_working_memory({
            "content": "⚠️ Persistent drive loop failed.",
            "event_type": "error",
            "priority": 3,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        return "introspective_planning"